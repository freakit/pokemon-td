// src/i18n/index.ts
export { I18nProvider, useTranslation } from './I18nProvider';
