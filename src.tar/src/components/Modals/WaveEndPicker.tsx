// src/components/Modals/WaveEndPicker.tsx

import React from 'react';
import { useGameStore } from '../../store/gameStore';
import { Item } from '../../types/game';

export const WaveEndPicker: React.FC = () => {
  const { waveEndItemPick, setWaveEndItemPick, addMoney, useItem } = useGameStore(state => ({
    waveEndItemPick: state.waveEndItemPick,
    setWaveEndItemPick: state.setWaveEndItemPick,
    addMoney: state.addMoney,
    useItem: state.useItem,
  }));

  if (!waveEndItemPick) return null;

  // 🔴 수정된 부분
  const handleSelect = (item: Item) => {
    // 보상 적용
    if (item.type === 'gold') {
      addMoney(item.value || 0);
    } else if (item.type === 'candy') {
      useItem('candy');
    } else if (item.type === 'heal') {
      const towers = useGameStore.getState().towers;
      let target = towers.filter(t => !t.isFainted).sort((a, b) => (a.currentHp / a.maxHp) - (b.currentHp / b.maxHp))[0];
      if (target) {
        const newHp = Math.min(target.maxHp, target.currentHp + (item.value || 200));
        useGameStore.getState().updateTower(target.id, { currentHp: newHp });
      }
    } else if (item.type === 'revive') {
      // 🔴 추가: 기력의 조각 - 기절한 포켓몬 부활
      useItem('revive');
    }
    
    // 모달 닫기 및 게임 재개
    setWaveEndItemPick(null);
    useGameStore.setState({ isPaused: false });
  };

  return (
    <div style={s.overlay}>
      <div style={s.modal}>
        <div style={s.header}>
          <h2 style={s.title}>🎉 웨이브 {useGameStore.getState().wave - 1} 클리어!</h2>
        </div>
        <p style={s.subtitle}>✨ 보상을 선택하세요 (모든 포켓몬의 체력이 회복되었습니다)</p>
        <div style={s.grid}>
          {waveEndItemPick.map((item, idx) => (
            <div key={idx} style={s.card} onClick={() => handleSelect(item)}>
              <div style={s.cardGlow}></div>
              <h3 style={s.itemName}>{item.name}</h3>
              <p style={s.itemEffect}>{item.effect}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// 고급 게임 UI 스타일
const s: Record<string, React.CSSProperties> = {
  overlay: { 
    position: 'fixed', 
    top: 0, 
    left: 0, 
    right: 0, 
    bottom: 0, 
    background: 'radial-gradient(circle at center, rgba(46, 204, 113, 0.3), rgba(0,0,0,0.95))',
    backdropFilter: 'blur(10px)',
    display: 'flex', 
    justifyContent: 'center', 
    alignItems: 'center', 
    zIndex: 1001,
    animation: 'fadeIn 0.3s ease-out'
  },
  modal: { 
    background: 'linear-gradient(145deg, #1a1f2e 0%, #0f1419 100%)',
    color: '#e8edf3', 
    borderRadius: '24px', 
    padding: '0',
    maxWidth: '1000px', // 🔴 수정: 4개 카드를 위해 넓이 증가
    width: '90%',
    boxShadow: '0 25px 80px rgba(46, 204, 113, 0.5), 0 0 1px 1px rgba(46, 204, 113, 0.3), inset 0 1px 0 rgba(255,255,255,0.1)',
    border: '2px solid rgba(46, 204, 113, 0.3)',
    animation: 'pulse 2s ease-in-out infinite'
  },
  header: {
    padding: '32px',
    background: 'linear-gradient(90deg, rgba(46, 204, 113, 0.2), transparent)',
    borderBottom: '2px solid rgba(46, 204, 113, 0.3)',
    textAlign: 'center' as 'center'
  },
  title: {
    fontSize: '36px',
    fontWeight: '900',
    margin: 0,
    background: 'linear-gradient(135deg, #2ecc71, #a8ffb8)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
    textShadow: '0 0 30px rgba(46, 204, 113, 0.6)',
    letterSpacing: '1px'
  },
  subtitle: {
    fontSize: '18px',
    margin: '24px 32px',
    textAlign: 'center' as 'center',
    color: '#a8b8c8',
    fontWeight: '600'
  },
  grid: { 
    display: 'flex', 
    gap: '20px', // 🔴 수정: 간격 조정
    padding: '0 32px 32px',
    justifyContent: 'center',
    flexWrap: 'wrap' as 'wrap' // 🔴 추가: 반응형 지원
  },
  card: { 
    flex: '1 1 200px', // 🔴 수정: 유연한 크기
    minWidth: '180px',
    maxWidth: '220px',
    background: 'linear-gradient(145deg, rgba(30, 40, 60, 0.9), rgba(15, 20, 35, 0.95))',
    border: '2px solid rgba(46, 204, 113, 0.4)',
    borderRadius: '20px', 
    padding: '28px 20px',
    cursor: 'pointer',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    boxShadow: '0 8px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.05)',
    position: 'relative' as 'relative',
    overflow: 'hidden',
    textAlign: 'center' as 'center'
  },
  cardGlow: {
    position: 'absolute' as 'absolute',
    top: '-50%',
    left: '-50%',
    width: '200%',
    height: '200%',
    background: 'radial-gradient(circle, rgba(46, 204, 113, 0.1) 0%, transparent 70%)',
    animation: 'pulse 3s ease-in-out infinite',
    pointerEvents: 'none' as 'none'
  },
  itemName: {
    fontSize: '22px', // 🔴 수정: 크기 조정
    fontWeight: '700',
    marginBottom: '12px',
    color: '#2ecc71',
    textShadow: '0 0 15px rgba(46, 204, 113, 0.6)',
    position: 'relative' as 'relative',
    zIndex: 1
  },
  itemEffect: {
    fontSize: '14px', // 🔴 수정: 크기 조정
    color: '#a8b8c8',
    lineHeight: '1.6',
    position: 'relative' as 'relative',
    zIndex: 1
  }
};