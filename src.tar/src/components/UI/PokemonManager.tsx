// src/components/UI/PokemonManager.tsx

import React from 'react';
import { useGameStore } from '../../store/gameStore';
import { Gender } from '../../types/game';

// 성별 아이콘
const getGenderIcon = (gender: Gender) => {
  if (gender === 'male') return '♂';
  if (gender === 'female') return '♀';
  return '⚪';
};

// 성별 색상
const getGenderColor = (gender: Gender) => {
  if (gender === 'male') return '#4A90E2';
  if (gender === 'female') return '#E91E63';
  return '#999';
};

export const PokemonManager: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { towers, sellTower } = useGameStore(state => ({
    towers: state.towers,
    sellTower: state.sellTower,
  }));

  const handleSell = (towerId: string, towerName: string, level: number) => {
    const sellPrice = level * 20;
    const confirmed = window.confirm(
      `${towerName} (Lv.${level})을(를) ${sellPrice}원에 판매하시겠습니까?`
    );
    
    if (confirmed) {
      sellTower(towerId);
    }
  };

  return (
    <div style={s.overlay}>
      <div style={s.modal}>
        <div style={s.header}>
          <h2 style={s.title}>🎒 포켓몬 관리 ({towers.length}/6)</h2>
          <button onClick={onClose} style={s.closeBtn}>✕</button>
        </div>
        
        {towers.length === 0 ? (
          <p style={s.emptyMessage}>보유 중인 포켓몬이 없습니다.</p>
        ) : (
          <div style={s.grid}>
            {towers.map(tower => {
              const sellPrice = tower.level * 20;
              const hpPercent = Math.round((tower.currentHp / tower.maxHp) * 100);
              
              return (
                <div key={tower.id} style={s.card}>
                  <div style={s.cardHeader}>
                    <img src={tower.sprite} alt={tower.name} style={s.img} />
                    {tower.isFainted && (
                      <div style={s.faintedBadge}>기절</div>
                    )}
                  </div>
                  
                  <div style={s.cardBody}>
                    <div style={s.nameRow}>
                      <h3 style={s.pokeName}>{tower.name}</h3>
                      <span style={{
                        fontSize: '18px',
                        fontWeight: 'bold',
                        color: getGenderColor(tower.gender),
                      }}>
                        {getGenderIcon(tower.gender)}
                      </span>
                    </div>
                    <div style={s.infoRow}>
                      <span>레벨</span>
                      <span style={s.infoValue}>{tower.level}</span>
                    </div>
                    <div style={s.infoRow}>
                      <span>HP</span>
                      <span style={s.infoValue}>
                        {Math.floor(tower.currentHp)}/{tower.maxHp} ({hpPercent}%)
                      </span>
                    </div>
                    <div style={s.infoRow}>
                      <span>처치</span>
                      <span style={s.infoValue}>{tower.kills}</span>
                    </div>
                    <div style={s.infoRow}>
                      <span>기술</span>
                      <span style={s.infoValue}>{tower.equippedMoves[0]?.name || 'N/A'}</span>
                    </div>
                  </div>
                  
                  <button 
                    style={s.sellBtn} 
                    onClick={() => handleSell(tower.id, tower.name, tower.level)}
                  >
                    💰 판매 ({sellPrice}원)
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

const s: Record<string, React.CSSProperties> = {
  overlay: { 
    position: 'fixed', 
    top: 0, 
    left: 0, 
    right: 0, 
    bottom: 0, 
    background: 'radial-gradient(circle at center, rgba(0,0,0,0.85), rgba(0,0,0,0.95))', 
    backdropFilter: 'blur(8px)',
    display: 'flex', 
    justifyContent: 'center', 
    alignItems: 'center', 
    zIndex: 999,
    animation: 'fadeIn 0.3s ease-out'
  },
  modal: { 
    background: 'linear-gradient(145deg, #2a2d3a, #1f2029)', 
    borderRadius: '20px', 
    padding: '30px',
    maxWidth: '1000px',
    width: '95%',
    maxHeight: '90vh',
    overflowY: 'auto',
    boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5)',
    border: '2px solid rgba(255, 255, 255, 0.1)',
  },
  header: { 
    display: 'flex', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    marginBottom: '20px'
  },
  title: { 
    fontSize: '28px', 
    fontWeight: 'bold',
    background: 'linear-gradient(135deg, #667eea, #764ba2)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
  },
  closeBtn: { 
    fontSize: '24px', 
    background: 'none', 
    border: 'none', 
    color: '#fff', 
    cursor: 'pointer',
    padding: '5px 10px',
    borderRadius: '5px',
    transition: 'background 0.2s',
  },
  emptyMessage: {
    fontSize: '18px',
    color: '#999',
    textAlign: 'center',
    padding: '40px',
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
    gap: '20px',
  },
  card: {
    background: 'rgba(255, 255, 255, 0.05)',
    borderRadius: '15px',
    padding: '15px',
    border: '2px solid rgba(255, 255, 255, 0.1)',
    transition: 'all 0.3s ease',
  },
  cardHeader: {
    position: 'relative',
    textAlign: 'center',
    marginBottom: '15px',
  },
  img: {
    width: '100px',
    height: '100px',
    imageRendering: 'pixelated',
  },
  faintedBadge: {
    position: 'absolute',
    top: '5px',
    right: '5px',
    background: '#e74c3c',
    color: 'white',
    fontSize: '12px',
    fontWeight: 'bold',
    padding: '4px 8px',
    borderRadius: '8px',
  },
  cardBody: {
    marginBottom: '15px',
  },
  nameRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    marginBottom: '12px',
  },
  pokeName: {
    fontSize: '20px',
    fontWeight: 'bold',
    margin: 0,
  },
  infoRow: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '8px 0',
    borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
    fontSize: '14px',
  },
  infoValue: {
    fontWeight: 'bold',
    color: '#FFD700',
  },
  sellBtn: {
    width: '100%',
    padding: '12px',
    fontSize: '16px',
    fontWeight: 'bold',
    background: 'linear-gradient(135deg, #e74c3c, #c0392b)',
    color: 'white',
    border: 'none',
    borderRadius: '12px',
    cursor: 'pointer',
    transition: 'all 0.3s ease',
  },
};
